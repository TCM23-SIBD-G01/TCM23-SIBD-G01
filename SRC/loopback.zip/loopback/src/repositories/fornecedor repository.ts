import {Getter, inject} from '@loopback/core';
import {DefaultCrudRepository, HasManyRepositoryFactory, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Encomenda} from '../models/encomenda';
import {Fornecedor} from '../models/fornecedor';
import {EncomendaFornecedorRepository} from './encomenda_fornecedor repository';

export class FornecedorRepository extends DefaultCrudRepository<
  Fornecedor,
  typeof Fornecedor.prototype.id
> {

  public readonly encomenda: HasManyRepositoryFactory<Encomenda, typeof Fornecedor.prototype.id>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('EncomendaRepository') protected encomendaRepositoryGetter: Getter<EncomendaFornecedorRepository>,
  ) {
    super(Fornecedor, dataSource);
    this.encomenda = this.createHasManyRepositoryFactoryFor('encomenda', encomendaRepositoryGetter,);
    this.registerInclusionResolver('encomenda', this.encomenda.inclusionResolver);
  }
}
