import {Getter, inject} from '@loopback/core';
import {DefaultCrudRepository, HasManyRepositoryFactory, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Funcionario} from '../models/funcionario';
import {Tarefa} from '../models/tarefa';
import {TarefaRepository} from './tarefa repository';

export class FuncionarioRepository extends DefaultCrudRepository<
  Funcionario,
  typeof Funcionario.prototype.nif
> {

  public readonly tarefa: HasManyRepositoryFactory<Tarefa, typeof Funcionario.prototype.nif>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('TarefaRepository') protected tarefaRepositoryGetter: Getter<TarefaRepository>,
  ) {
    super(Funcionario, dataSource);
    this.tarefa = this.createHasManyRepositoryFactoryFor('tarefa', this.tarefaRepositoryGetter,);
    this.registerInclusionResolver('tarefa', this.tarefa.inclusionResolver);
  }
}
