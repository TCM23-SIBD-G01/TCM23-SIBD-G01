import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Funcionario} from '../models/funcionario';
import {Tarefa} from '../models/tarefa';
import {FuncionarioRepository} from './funcionario repository';

export class TarefaRepository extends DefaultCrudRepository<
  Tarefa,
  typeof Funcionario.prototype.nif

> {

  public readonly funcionario: BelongsToAccessor<Funcionario, typeof Funcionario.prototype.nif>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('FuncionarioRepository') protected funcionarioRepositoryGetter: Getter<FuncionarioRepository>,
  ) {
    super(Tarefa, dataSource);
    this.funcionario = this.createBelongsToAccessorFor('tarefa', this.funcionarioRepositoryGetter,);
    this.registerInclusionResolver('tarefa', this.funcionario.inclusionResolver);
  }
}
