import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Funcionario} from '../models/funcionario';
import {Material} from '../models/material';
import {FuncionarioRepository} from './funcionario repository';

export class MaterialRepository extends DefaultCrudRepository<
  Material,
  typeof Funcionario.prototype.nif

> {

  public readonly funcionario: BelongsToAccessor<Funcionario, typeof Funcionario.prototype.nif>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('FuncionarioRepository') protected funcionarioRepositoryGetter: Getter<FuncionarioRepository>,
  ) {
    super(Material, dataSource);
    this.funcionario = this.createBelongsToAccessorFor('material', this.funcionarioRepositoryGetter,);
    this.registerInclusionResolver('material', this.funcionario.inclusionResolver);
  }
}
