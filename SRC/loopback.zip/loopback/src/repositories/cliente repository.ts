import {Getter, inject} from '@loopback/core';
import {DefaultCrudRepository, HasManyRepositoryFactory, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Cliente} from '../models/cliente';
import {Compra} from '../models/compra';
import {CompraRepository} from './compra repository';

export class ClienteRepository extends DefaultCrudRepository<
  Cliente,
  typeof Cliente.prototype.nif
> {

  public readonly compra: HasManyRepositoryFactory<Compra, typeof Cliente.prototype.nif>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('CompraRepository') protected compraRepositoryGetter: Getter<CompraRepository>,
  ) {
    super(Cliente, dataSource);
    this.compra = this.createHasManyRepositoryFactoryFor('compra', compraRepositoryGetter,);
    this.registerInclusionResolver('compra', this.compra.inclusionResolver);
  }
}
