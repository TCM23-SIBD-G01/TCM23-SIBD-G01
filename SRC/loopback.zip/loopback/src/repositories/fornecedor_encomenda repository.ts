import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Encomenda} from '../models/encomenda';
import {Fornecedor} from '../models/fornecedor';
import {EncomendaRepository} from './encomenda repository';

export class FornecedorEncomendaRepository extends DefaultCrudRepository<
  Fornecedor,
  typeof Encomenda.prototype.id

> {

  public readonly encomenda: BelongsToAccessor<Encomenda, typeof Encomenda.prototype.id>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('EncomendaRepository') protected encomendaRepositoryGetter: Getter<EncomendaRepository>,
  ) {
    super(Fornecedor, dataSource);
    this.encomenda = this.createBelongsToAccessorFor('fornecedor', this.encomendaRepositoryGetter,);
    this.registerInclusionResolver('fornecedor', this.encomenda.inclusionResolver);
  }
}
