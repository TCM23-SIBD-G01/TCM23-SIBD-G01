import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Cor} from '../models/cor';
import {Produto} from '../models/produto';
import {ProdutoRepository} from './produto repository';

export class CorRepository extends DefaultCrudRepository<
  Cor,
  typeof Produto.prototype.codigoBarras

> {

  public readonly produto: BelongsToAccessor<Produto, typeof Produto.prototype.codigoBarras>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('ProdutoRepository') protected produtoRepositoryGetter: Getter<ProdutoRepository>,
  ) {
    super(Cor, dataSource);
    this.produto = this.createBelongsToAccessorFor('cor', produtoRepositoryGetter,);
    this.registerInclusionResolver('cor', this.produto.inclusionResolver);
  }
}
