import {Getter, inject} from '@loopback/core';
import {DefaultCrudRepository, HasManyRepositoryFactory, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Encomenda} from '../models/encomenda';
import {Tarefa} from '../models/tarefa';
import {TarefaRepository} from './tarefa repository';

export class EncomendaRepository extends DefaultCrudRepository<
  Encomenda,
  typeof Encomenda.prototype.id
> {

  public readonly tarefa: HasManyRepositoryFactory<Tarefa, typeof Encomenda.prototype.id>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('TarefaRepository') protected tarefaRepositoryGetter: Getter<TarefaRepository>,
  ) {
    super(Encomenda, dataSource);
    this.tarefa = this.createHasManyRepositoryFactoryFor('tarefa', this.tarefaRepositoryGetter,);
    this.registerInclusionResolver('tarefa', this.tarefa.inclusionResolver);
  }
}
