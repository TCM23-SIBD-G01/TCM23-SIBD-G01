import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Produto} from '../models/produto';
import {Stock} from '../models/stock';
import {StockRepository} from './stock repository';

export class ProdutoRepository extends DefaultCrudRepository<
  Produto,
  typeof Stock.prototype.codigoBarras

> {

  public readonly stock: BelongsToAccessor<Stock, typeof Stock.prototype.codigoBarras>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('StockRepository') protected stockRepositoryGetter: Getter<StockRepository>,
  ) {
    super(Produto, dataSource);
    this.stock = this.createBelongsToAccessorFor('produto', stockRepositoryGetter,);
    this.registerInclusionResolver('produto', this.stock.inclusionResolver);
  }
}
