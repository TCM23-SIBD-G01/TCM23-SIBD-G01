import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Funcionario} from '../models/funcionario';
import {Tamanho} from '../models/tamanho';
import {FuncionarioRepository} from './funcionario repository';

export class TamanhoRepository extends DefaultCrudRepository<
  Tamanho,
  typeof Funcionario.prototype.nif

> {

  public readonly funcionario: BelongsToAccessor<Funcionario, typeof Funcionario.prototype.nif>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('FuncionarioRepository') protected funcionarioRepositoryGetter: Getter<FuncionarioRepository>,
  ) {
    super(Tamanho, dataSource);
    this.funcionario = this.createBelongsToAccessorFor('tamanho', this.funcionarioRepositoryGetter,);
    this.registerInclusionResolver('tamanho', this.funcionario.inclusionResolver);
  }
}
