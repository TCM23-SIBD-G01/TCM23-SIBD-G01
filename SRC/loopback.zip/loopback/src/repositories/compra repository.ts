import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Cliente} from '../models/cliente';
import {Compra} from '../models/compra';
import {ClienteRepository} from './cliente repository';

export class CompraRepository extends DefaultCrudRepository<
  Compra,
  typeof Cliente.prototype.nif

> {

  public readonly cliente: BelongsToAccessor<Cliente, typeof Cliente.prototype.nif>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('ClienteRepository') protected clienteRepositoryGetter: Getter<ClienteRepository>,
  ) {
    super(Compra, dataSource);
    this.cliente = this.createBelongsToAccessorFor('compra', clienteRepositoryGetter,);
    this.registerInclusionResolver('compra', this.cliente.inclusionResolver);
  }
}
