import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Encomenda} from '../models/encomenda';
import {Loja} from '../models/loja';
import {LojaRepository} from './loja repository';

export class EncomendaLojaRepository extends DefaultCrudRepository<
  Encomenda,
  typeof Loja.prototype.id

> {

  public readonly loja: BelongsToAccessor<Loja, typeof Loja.prototype.id>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('LojaRepository') protected lojaRepositoryGetter: Getter<LojaRepository>,
  ) {
    super(Encomenda, dataSource);
    this.loja = this.createBelongsToAccessorFor('encomenda', this.lojaRepositoryGetter,);
    this.registerInclusionResolver('encomenda', this.loja.inclusionResolver);
  }
}
