import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Encomenda} from '../models/encomenda';
import {Loja} from '../models/loja';
import {EncomendaRepository} from './encomenda repository';

export class LojaEncomendaRepository extends DefaultCrudRepository<
  Loja,
  typeof Encomenda.prototype.id

> {

  public readonly encomenda: BelongsToAccessor<Encomenda, typeof Encomenda.prototype.id>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('EncomendaRepository') protected encomendaRepositoryGetter: Getter<EncomendaRepository>,
  ) {
    super(Loja, dataSource);
    this.encomenda = this.createBelongsToAccessorFor('loja', this.encomendaRepositoryGetter,);
    this.registerInclusionResolver('loja', this.encomenda.inclusionResolver);
  }
}
