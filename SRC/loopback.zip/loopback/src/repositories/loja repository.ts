import {Getter, inject} from '@loopback/core';
import {DefaultCrudRepository, HasManyRepositoryFactory, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Encomenda} from '../models/encomenda';
import {Loja} from '../models/loja';
import {EncomendaLojaRepository} from './encomenda_loja repository';

export class LojaRepository extends DefaultCrudRepository<
  Loja,
  typeof Loja.prototype.id
> {

  public readonly encomenda: HasManyRepositoryFactory<Encomenda, typeof Loja.prototype.id>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('EncomendaRepository') protected encomendaRepositoryGetter: Getter<EncomendaLojaRepository>,
  ) {
    super(Loja, dataSource);
    this.encomenda = this.createHasManyRepositoryFactoryFor('encomenda', encomendaRepositoryGetter,);
    this.registerInclusionResolver('encomenda', this.encomenda.inclusionResolver);
  }
}
