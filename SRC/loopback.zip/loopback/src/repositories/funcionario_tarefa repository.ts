import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Funcionario} from '../models/funcionario';
import {Tarefa} from '../models/tarefa';
import {TarefaRepository} from './tarefa repository';

export class FuncionarioTarefaRepository extends DefaultCrudRepository<
  Funcionario,
  typeof Tarefa.prototype.idFuncionario

> {

  public readonly tarefa: BelongsToAccessor<Tarefa, typeof Tarefa.prototype.idFuncionario>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('TarefaRepository') protected tarefaRepositoryGetter: Getter<TarefaRepository>,
  ) {
    super(Funcionario, dataSource);
    this.tarefa = this.createBelongsToAccessorFor('funcionario', this.tarefaRepositoryGetter,);
    this.registerInclusionResolver('funcionario', this.tarefa.inclusionResolver);
  }
}
