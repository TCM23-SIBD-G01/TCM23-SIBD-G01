import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Encomenda} from '../models/encomenda';
import {Fornecedor} from '../models/fornecedor';
import {FornecedorRepository} from './fornecedor repository';

export class EncomendaFornecedorRepository extends DefaultCrudRepository<
  Encomenda,
  typeof Fornecedor.prototype.id

> {

  public readonly fornecedor: BelongsToAccessor<Fornecedor, typeof Fornecedor.prototype.id>;

  constructor(
    @inject('lojas') dataSource: DbDataSource, @repository.getter('FornecedorRepository') protected fornecedorRepositoryGetter: Getter<FornecedorRepository>,
  ) {
    super(Encomenda, dataSource);
    this.fornecedor = this.createBelongsToAccessorFor('encomenda', this.fornecedorRepositoryGetter,);
    this.registerInclusionResolver('encomenda', this.fornecedor.inclusionResolver);
  }
}
