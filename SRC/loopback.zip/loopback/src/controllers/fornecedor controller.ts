import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  param,
  patch,
  post,
  put,
  requestBody,
  response,
} from '@loopback/rest';
import {Fornecedor} from '../models/fornecedor';
import {FornecedorRepository} from '../repositories';

export class FornecedorControllerController {
  constructor(
    @repository(FornecedorRepository)
    public FornecedorRepository: FornecedorRepository,
  ) { }

  @post('/Fornecedor')
  @response(200, {
    description: 'Fornecedor model instance',
    content: {'application/json': {schema: getModelSchemaRef(Fornecedor)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Fornecedor, {
            title: 'NewFornecedor',
            exclude: ['id'],
          }),
        },
      },
    })
    Fornecedor: Omit<Fornecedor, 'id'>,
  ): Promise<Fornecedor> {
    return this.FornecedorRepository.create(Fornecedor);
  }

  @get('/Fornecedor/count')
  @response(200, {
    description: 'Fornecedor model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Fornecedor) where?: Where<Fornecedor>,
  ): Promise<Count> {
    return this.FornecedorRepository.count(where);
  }

  @get('/Fornecedor')
  @response(200, {
    description: 'Array of Fornecedor model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Fornecedor, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Fornecedor) filter?: Filter<Fornecedor>,
  ): Promise<Fornecedor[]> {
    return this.FornecedorRepository.find(filter);
  }

  @patch('/Fornecedor')
  @response(200, {
    description: 'Fornecedor PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Fornecedor, {partial: true}),
        },
      },
    })
    Fornecedor: Fornecedor,
    @param.where(Fornecedor) where?: Where<Fornecedor>,
  ): Promise<Count> {
    return this.FornecedorRepository.updateAll(Fornecedor, where);
  }

  @get('/Fornecedor/{id}')
  @response(200, {
    description: 'Fornecedor model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Fornecedor, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Fornecedor, {exclude: 'where'}) filter?: FilterExcludingWhere<Fornecedor>
  ): Promise<Fornecedor> {
    return this.FornecedorRepository.findById(id, filter);
  }

  @patch('/Fornecedor/{id}')
  @response(204, {
    description: 'Fornecedor PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Fornecedor, {partial: true}),
        },
      },
    })
    Fornecedor: Fornecedor,
  ): Promise<void> {
    await this.FornecedorRepository.updateById(id, Fornecedor);
  }

  @put('/Fornecedor/{id}')
  @response(204, {
    description: 'Fornecedor PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() Fornecedor: Fornecedor,
  ): Promise<void> {
    await this.FornecedorRepository.replaceById(id, Fornecedor);
  }

  @del('/Fornecedor/{id}')
  @response(204, {
    description: 'Fornecedor DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.FornecedorRepository.deleteById(id);
  }
}
