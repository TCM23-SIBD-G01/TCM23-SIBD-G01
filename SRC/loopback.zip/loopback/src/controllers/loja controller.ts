import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  param,
  patch,
  post,
  put,
  requestBody,
  response,
} from '@loopback/rest';
import {Loja} from '../models/loja';
import {LojaRepository} from '../repositories';

export class LojaControllerController {
  constructor(
    @repository(LojaRepository)
    public clienteRepository: LojaRepository,
  ) { }

  @post('/cliente')
  @response(200, {
    description: 'Loja model instance',
    content: {'application/json': {schema: getModelSchemaRef(Loja)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Loja, {
            title: 'NewLoja',
            exclude: ['id'],
          }),
        },
      },
    })
    cliente: Omit<Loja, 'id'>,
  ): Promise<Loja> {
    return this.clienteRepository.create(cliente);
  }

  @get('/cliente/count')
  @response(200, {
    description: 'Loja model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Loja) where?: Where<Loja>,
  ): Promise<Count> {
    return this.clienteRepository.count(where);
  }

  @get('/cliente')
  @response(200, {
    description: 'Array of Loja model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Loja, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Loja) filter?: Filter<Loja>,
  ): Promise<Loja[]> {
    return this.clienteRepository.find(filter);
  }

  @patch('/cliente')
  @response(200, {
    description: 'Loja PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Loja, {partial: true}),
        },
      },
    })
    cliente: Loja,
    @param.where(Loja) where?: Where<Loja>,
  ): Promise<Count> {
    return this.clienteRepository.updateAll(cliente, where);
  }

  @get('/cliente/{id}')
  @response(200, {
    description: 'Loja model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Loja, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Loja, {exclude: 'where'}) filter?: FilterExcludingWhere<Loja>
  ): Promise<Loja> {
    return this.clienteRepository.findById(id, filter);
  }

  @patch('/cliente/{id}')
  @response(204, {
    description: 'Loja PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Loja, {partial: true}),
        },
      },
    })
    cliente: Loja,
  ): Promise<void> {
    await this.clienteRepository.updateById(id, cliente);
  }

  @put('/cliente/{id}')
  @response(204, {
    description: 'Loja PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() cliente: Loja,
  ): Promise<void> {
    await this.clienteRepository.replaceById(id, cliente);
  }

  @del('/cliente/{id}')
  @response(204, {
    description: 'Loja DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.clienteRepository.deleteById(id);
  }
}
