import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  param,
  patch,
  post,
  put,
  requestBody,
  response,
} from '@loopback/rest';
import {Encomenda} from '../models/encomenda';
import {EncomendaRepository} from '../repositories';

export class EncomendaControllerController {
  constructor(
    @repository(EncomendaRepository)
    public EncomendaRepository: EncomendaRepository,
  ) { }

  @post('/Encomenda')
  @response(200, {
    description: 'Encomenda model instance',
    content: {'application/json': {schema: getModelSchemaRef(Encomenda)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Encomenda, {
            title: 'NewEncomenda',
            exclude: ['id'],
          }),
        },
      },
    })
    Encomenda: Omit<Encomenda, 'id'>,
  ): Promise<Encomenda> {
    return this.EncomendaRepository.create(Encomenda);
  }

  @get('/Encomenda/count')
  @response(200, {
    description: 'Encomenda model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Encomenda) where?: Where<Encomenda>,
  ): Promise<Count> {
    return this.EncomendaRepository.count(where);
  }

  @get('/Encomenda')
  @response(200, {
    description: 'Array of Encomenda model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Encomenda, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Encomenda) filter?: Filter<Encomenda>,
  ): Promise<Encomenda[]> {
    return this.EncomendaRepository.find(filter);
  }

  @patch('/Encomenda')
  @response(200, {
    description: 'Encomenda PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Encomenda, {partial: true}),
        },
      },
    })
    Encomenda: Encomenda,
    @param.where(Encomenda) where?: Where<Encomenda>,
  ): Promise<Count> {
    return this.EncomendaRepository.updateAll(Encomenda, where);
  }

  @get('/Encomenda/{id}')
  @response(200, {
    description: 'Encomenda model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Encomenda, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Encomenda, {exclude: 'where'}) filter?: FilterExcludingWhere<Encomenda>
  ): Promise<Encomenda> {
    return this.EncomendaRepository.findById(id, filter);
  }

  @patch('/Encomenda/{id}')
  @response(204, {
    description: 'Encomenda PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Encomenda, {partial: true}),
        },
      },
    })
    Encomenda: Encomenda,
  ): Promise<void> {
    await this.EncomendaRepository.updateById(id, Encomenda);
  }

  @put('/Encomenda/{id}')
  @response(204, {
    description: 'Encomenda PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() Encomenda: Encomenda,
  ): Promise<void> {
    await this.EncomendaRepository.replaceById(id, Encomenda);
  }

  @del('/Encomenda/{id}')
  @response(204, {
    description: 'Encomenda DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.EncomendaRepository.deleteById(id);
  }
}
