import {
  repository,
} from '@loopback/repository';
import {
  get,
  getModelSchemaRef,
  param,
} from '@loopback/rest';
import {
  Encomenda,
} from '../models/encomenda';
import {
  Fornecedor,
} from '../models/fornecedor';
import {EncomendaFornecedorRepository} from '../repositories';

export class encomenda_fornecedorController {
  constructor(
    @repository(EncomendaFornecedorRepository)
    public encomendaFornecedorRepository: EncomendaFornecedorRepository,
  ) { }

  @get('/encomendaFornecedor/{id}/fornecedor', {
    responses: {
      '200': {
        description: 'Fornecedor belonging to Encomenda',
        content: {
          'application/json': {
            schema: {type: 'array', items: getModelSchemaRef(Fornecedor)},
          },
        },
      },
    },
  })
  async getFornecedor(
    @param.path.number('id') id: typeof Encomenda.prototype.id,
  ): Promise<Fornecedor> {
    return this.encomendaFornecedorRepository.fornecedor(id);
  }
}
