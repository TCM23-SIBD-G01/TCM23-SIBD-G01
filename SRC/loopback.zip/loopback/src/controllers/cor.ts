import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  param,
  patch,
  post,
  put,
  requestBody,
  response,
} from '@loopback/rest';
import {Cor} from '../models/cor';
import {CorRepository} from '../repositories';

export class CorControllerController {
  constructor(
    @repository(CorRepository)
    public CorRepository: CorRepository,
  ) { }

  @post('/Cor')
  @response(200, {
    description: 'Cor model instance',
    content: {'application/json': {schema: getModelSchemaRef(Cor)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Cor, {
            title: 'NewCor',
            exclude: ['codigoHexadecimal'],
          }),
        },
      },
    })
    Cor: Omit<Cor, 'codigoHexadecimal'>,
  ): Promise<Cor> {
    return this.CorRepository.create(Cor);
  }

  @get('/Cor/count')
  @response(200, {
    description: 'Cor model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Cor) where?: Where<Cor>,
  ): Promise<Count> {
    return this.CorRepository.count(where);
  }

  @get('/Cor')
  @response(200, {
    description: 'Array of Cor model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Cor, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Cor) filter?: Filter<Cor>,
  ): Promise<Cor[]> {
    return this.CorRepository.find(filter);
  }

  @patch('/Cor')
  @response(200, {
    description: 'Cor PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Cor, {partial: true}),
        },
      },
    })
    Cor: Cor,
    @param.where(Cor) where?: Where<Cor>,
  ): Promise<Count> {
    return this.CorRepository.updateAll(Cor, where);
  }

  @get('/Cor/{id}')
  @response(200, {
    description: 'Cor model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Cor, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Cor, {exclude: 'where'}) filter?: FilterExcludingWhere<Cor>
  ): Promise<Cor> {
    return this.CorRepository.findById(id, filter);
  }

  @patch('/Cor/{id}')
  @response(204, {
    description: 'Cor PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Cor, {partial: true}),
        },
      },
    })
    Cor: Cor,
  ): Promise<void> {
    await this.CorRepository.updateById(id, Cor);
  }

  @put('/Cor/{id}')
  @response(204, {
    description: 'Cor PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() Cor: Cor,
  ): Promise<void> {
    await this.CorRepository.replaceById(id, Cor);
  }

  @del('/Cor/{id}')
  @response(204, {
    description: 'Cor DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.CorRepository.deleteById(id);
  }
}
