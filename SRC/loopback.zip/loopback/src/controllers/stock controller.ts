import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  param,
  patch,
  post,
  put,
  requestBody,
  response,
} from '@loopback/rest';
import {Stock} from '../models/stock';
import {StockRepository} from '../repositories';

export class StockControllerController {
  constructor(
    @repository(StockRepository)
    public clienteRepository: StockRepository,
  ) { }

  @post('/cliente')
  @response(200, {
    description: 'Stock model instance',
    content: {'application/json': {schema: getModelSchemaRef(Stock)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Stock, {
            title: 'NewStock',
            exclude: ['codigoBarras'],
          }),
        },
      },
    })
    cliente: Omit<Stock, 'codigoBarras'>,
  ): Promise<Stock> {
    return this.clienteRepository.create(cliente);
  }

  @get('/cliente/count')
  @response(200, {
    description: 'Stock model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Stock) where?: Where<Stock>,
  ): Promise<Count> {
    return this.clienteRepository.count(where);
  }

  @get('/cliente')
  @response(200, {
    description: 'Array of Stock model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Stock, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Stock) filter?: Filter<Stock>,
  ): Promise<Stock[]> {
    return this.clienteRepository.find(filter);
  }

  @patch('/cliente')
  @response(200, {
    description: 'Stock PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Stock, {partial: true}),
        },
      },
    })
    cliente: Stock,
    @param.where(Stock) where?: Where<Stock>,
  ): Promise<Count> {
    return this.clienteRepository.updateAll(cliente, where);
  }

  @get('/cliente/{id}')
  @response(200, {
    description: 'Stock model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Stock, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Stock, {exclude: 'where'}) filter?: FilterExcludingWhere<Stock>
  ): Promise<Stock> {
    return this.clienteRepository.findById(id, filter);
  }

  @patch('/cliente/{id}')
  @response(204, {
    description: 'Stock PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Stock, {partial: true}),
        },
      },
    })
    cliente: Stock,
  ): Promise<void> {
    await this.clienteRepository.updateById(id, cliente);
  }

  @put('/cliente/{id}')
  @response(204, {
    description: 'Stock PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() cliente: Stock,
  ): Promise<void> {
    await this.clienteRepository.replaceById(id, cliente);
  }

  @del('/cliente/{id}')
  @response(204, {
    description: 'Stock DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.clienteRepository.deleteById(id);
  }
}
