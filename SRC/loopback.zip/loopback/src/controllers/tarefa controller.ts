import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  param,
  patch,
  post,
  put,
  requestBody,
  response,
} from '@loopback/rest';
import {Tarefa} from '../models/tarefa';
import {TarefaRepository} from '../repositories';

export class TarefaControllerController {
  constructor(
    @repository(TarefaRepository)
    public TarefaRepository: TarefaRepository,
  ) { }

  @post('/Tarefa')
  @response(200, {
    description: 'Tarefa model instance',
    content: {'application/json': {schema: getModelSchemaRef(Tarefa)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Tarefa, {
            title: 'NewTarefa',
            exclude: ['idFuncionario'],
          }),
        },
      },
    })
    Tarefa: Omit<Tarefa, 'idFuncionario'>,
  ): Promise<Tarefa> {
    return this.TarefaRepository.create(Tarefa);
  }

  @get('/Tarefa/count')
  @response(200, {
    description: 'Tarefa model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Tarefa) where?: Where<Tarefa>,
  ): Promise<Count> {
    return this.TarefaRepository.count(where);
  }

  @get('/Tarefa')
  @response(200, {
    description: 'Array of Tarefa model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Tarefa, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Tarefa) filter?: Filter<Tarefa>,
  ): Promise<Tarefa[]> {
    return this.TarefaRepository.find(filter);
  }

  @patch('/Tarefa')
  @response(200, {
    description: 'Tarefa PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Tarefa, {partial: true}),
        },
      },
    })
    Tarefa: Tarefa,
    @param.where(Tarefa) where?: Where<Tarefa>,
  ): Promise<Count> {
    return this.TarefaRepository.updateAll(Tarefa, where);
  }

  @get('/Tarefa/{id}')
  @response(200, {
    description: 'Tarefa model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Tarefa, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Tarefa, {exclude: 'where'}) filter?: FilterExcludingWhere<Tarefa>
  ): Promise<Tarefa> {
    return this.TarefaRepository.findById(id, filter);
  }

  @patch('/Tarefa/{id}')
  @response(204, {
    description: 'Tarefa PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Tarefa, {partial: true}),
        },
      },
    })
    Tarefa: Tarefa,
  ): Promise<void> {
    await this.TarefaRepository.updateById(id, Tarefa);
  }

  @put('/Tarefa/{id}')
  @response(204, {
    description: 'Tarefa PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() Tarefa: Tarefa,
  ): Promise<void> {
    await this.TarefaRepository.replaceById(id, Tarefa);
  }

  @del('/Tarefa/{id}')
  @response(204, {
    description: 'Tarefa DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.TarefaRepository.deleteById(id);
  }
}
