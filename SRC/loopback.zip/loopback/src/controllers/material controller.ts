import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  param,
  patch,
  post,
  put,
  requestBody,
  response,
} from '@loopback/rest';
import {Material} from '../models/material';
import {MaterialRepository} from '../repositories';

export class MaterialControllerController {
  constructor(
    @repository(MaterialRepository)
    public MaterialRepository: MaterialRepository,
  ) { }

  @post('/Material')
  @response(200, {
    description: 'Material model instance',
    content: {'application/json': {schema: getModelSchemaRef(Material)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Material, {
            title: 'NewMaterial',
            exclude: ['nome'],
          }),
        },
      },
    })
    Material: Omit<Material, 'nome'>,
  ): Promise<Material> {
    return this.MaterialRepository.create(Material);
  }

  @get('/Material/count')
  @response(200, {
    description: 'Material model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Material) where?: Where<Material>,
  ): Promise<Count> {
    return this.MaterialRepository.count(where);
  }

  @get('/Material')
  @response(200, {
    description: 'Array of Material model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Material, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Material) filter?: Filter<Material>,
  ): Promise<Material[]> {
    return this.MaterialRepository.find(filter);
  }

  @patch('/Material')
  @response(200, {
    description: 'Material PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Material, {partial: true}),
        },
      },
    })
    Material: Material,
    @param.where(Material) where?: Where<Material>,
  ): Promise<Count> {
    return this.MaterialRepository.updateAll(Material, where);
  }

  @get('/Material/{id}')
  @response(200, {
    description: 'Material model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Material, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Material, {exclude: 'where'}) filter?: FilterExcludingWhere<Material>
  ): Promise<Material> {
    return this.MaterialRepository.findById(id, filter);
  }

  @patch('/Material/{id}')
  @response(204, {
    description: 'Material PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Material, {partial: true}),
        },
      },
    })
    Material: Material,
  ): Promise<void> {
    await this.MaterialRepository.updateById(id, Material);
  }

  @put('/Material/{id}')
  @response(204, {
    description: 'Material PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() Material: Material,
  ): Promise<void> {
    await this.MaterialRepository.replaceById(id, Material);
  }

  @del('/Material/{id}')
  @response(204, {
    description: 'Material DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.MaterialRepository.deleteById(id);
  }
}
