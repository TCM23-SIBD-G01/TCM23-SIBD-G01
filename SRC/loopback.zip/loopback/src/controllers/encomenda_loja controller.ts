import {
  repository,
} from '@loopback/repository';
import {
  get,
  getModelSchemaRef,
  param,
} from '@loopback/rest';
import {
  Encomenda,
} from '../models/encomenda';
import {
  Loja,
} from '../models/loja';
import {EncomendaLojaRepository} from '../repositories';

export class encomenda_lojaController {
  constructor(
    @repository(EncomendaLojaRepository)
    public encomendaLojaRepository: EncomendaLojaRepository,
  ) { }

  @get('/encomendaLoja/{id}/loja', {
    responses: {
      '200': {
        description: 'Loja belonging to Encomenda',
        content: {
          'application/json': {
            schema: {type: 'array', items: getModelSchemaRef(Loja)},
          },
        },
      },
    },
  })
  async getLoja(
    @param.path.number('id') id: typeof Encomenda.prototype.id,
  ): Promise<Loja> {
    return this.encomendaLojaRepository.loja(id);
  }
}
