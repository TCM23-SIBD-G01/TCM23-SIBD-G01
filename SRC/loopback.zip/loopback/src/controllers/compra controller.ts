import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  param,
  patch,
  post,
  put,
  requestBody,
  response,
} from '@loopback/rest';
import {Compra} from '../models/compra';
import {CompraRepository} from '../repositories';

export class CompraControllerController {
  constructor(
    @repository(CompraRepository)
    public CompraRepository: CompraRepository,
  ) { }

  @post('/Compra')
  @response(200, {
    description: 'Compra model instance',
    content: {'application/json': {schema: getModelSchemaRef(Compra)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Compra, {
            title: 'NewCompra',
            exclude: ['id'],
          }),
        },
      },
    })
    Compra: Omit<Compra, 'id'>,
  ): Promise<Compra> {
    return this.CompraRepository.create(Compra);
  }

  @get('/Compra/count')
  @response(200, {
    description: 'Compra model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Compra) where?: Where<Compra>,
  ): Promise<Count> {
    return this.CompraRepository.count(where);
  }

  @get('/Compra')
  @response(200, {
    description: 'Array of Compra model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Compra, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Compra) filter?: Filter<Compra>,
  ): Promise<Compra[]> {
    return this.CompraRepository.find(filter);
  }

  @patch('/Compra')
  @response(200, {
    description: 'Compra PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Compra, {partial: true}),
        },
      },
    })
    Compra: Compra,
    @param.where(Compra) where?: Where<Compra>,
  ): Promise<Count> {
    return this.CompraRepository.updateAll(Compra, where);
  }

  @get('/Compra/{id}')
  @response(200, {
    description: 'Compra model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Compra, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Compra, {exclude: 'where'}) filter?: FilterExcludingWhere<Compra>
  ): Promise<Compra> {
    return this.CompraRepository.findById(id, filter);
  }

  @patch('/Compra/{id}')
  @response(204, {
    description: 'Compra PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Compra, {partial: true}),
        },
      },
    })
    Compra: Compra,
  ): Promise<void> {
    await this.CompraRepository.updateById(id, Compra);
  }

  @put('/Compra/{id}')
  @response(204, {
    description: 'Compra PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() Compra: Compra,
  ): Promise<void> {
    await this.CompraRepository.replaceById(id, Compra);
  }

  @del('/Compra/{id}')
  @response(204, {
    description: 'Compra DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.CompraRepository.deleteById(id);
  }
}
