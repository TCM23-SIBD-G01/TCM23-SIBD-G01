export * from './lojas';
