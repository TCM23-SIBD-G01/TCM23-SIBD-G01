import {inject, lifeCycleObserver, LifeCycleObserver} from '@loopback/core';
import {juggler} from '@loopback/repository';

const config = {
  name: 'lojas',
  connector: 'mysql',
  url: 'mysql://root@localhost/lojas',
  host: '',
  port: 0,
  user: '',
  password: '',
  database: ''
};

@lifeCycleObserver('datasource')
export class DbDataSource extends juggler.DataSource
  implements LifeCycleObserver {
  static dataSourceName = 'lojas';
  static readonly defaultConfig = config;

  constructor(
    @inject('datasources.config.lojas', {optional: true})
    dsConfig: object = config,
  ) {
    super(dsConfig);
  }
}
