import {Entity, property} from '@loopback/repository';

export class Produto extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: false,
    required: true,
  })
  codigoBarras: number;

  @property({
    type: 'enum',
    required: true,
  })
  sexo: Sexo;

  @property({
    type: 'enum',
    required: true,
  })
  estacao: Estacao;

  @property({
    type: 'string',
    required: true,
  })
  nome: string;

  @property({
    type: 'number',
    required: true,
  })
  preco: number;

  @property({
    type: 'number',
    required: true,
  })
  quantidade: number;
}
