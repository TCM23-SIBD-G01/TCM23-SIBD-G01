import {Entity, property} from '@loopback/repository';

export class Material extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: false,
    required: true,
  })
  nome: string;

  @property({
    type: 'string',
    required: true,
  })
  composicao: string;

  @property({
    type: 'string',
    required: true,
  })
  instrucoes: string;

  @property({
    type: 'string',
    required: true,
  })
  propriedades: string;
}
