import {Entity, property} from '@loopback/repository';

export class Stock extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: false,
    required: true,
  })
  codigoBarras: number;

  @property({
    type: 'number',
    required: true,
  })
  quantidade: number;
}
