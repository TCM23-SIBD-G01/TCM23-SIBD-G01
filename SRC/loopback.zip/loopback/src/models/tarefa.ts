import {Entity, property} from '@loopback/repository';

export class Tarefa extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: false,
    required: true,
  })
  idFuncionario: number;

  @property({
    type: 'string',
    required: true,
  })
  horario: string;

  @property({
    type: 'enum',
    required: true,
  })
  categoria: Categoria;

  @property({
    type: 'string',
    required: true,
  })
  data: string;

  @property({
    type: 'enum',
    required: false,
  })
  status: Status;

  @property({
    type: 'string',
    required: true,
  })
  descricao: string;
}
