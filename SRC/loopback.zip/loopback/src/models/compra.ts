import {Entity, property} from '@loopback/repository';

export class Compra extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: false,
    required: true,
  })
  id: string;

  @property({
    type: 'string',
    required: true,
  })
  data: string;

  @property({
    type: 'number',
    required: true,
  })
  nifCliente: number;

  @property({
    type: 'number',
    required: true,
  })
  valorCompra: number;

  @property({
    type: 'number',
    required: false,
  })
  descontosAplicados: number;

  @property({
    type: 'enum',
    required: true,
  })
  metodoPagamento: MetodoPagamento;
}
