import {Entity, property} from '@loopback/repository';

export class Cor extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: false,
    required: true,
  })
  codigoHexadecimal: string;

  @property({
    type: 'string',
    required: true,
  })
  nome: string;
}
