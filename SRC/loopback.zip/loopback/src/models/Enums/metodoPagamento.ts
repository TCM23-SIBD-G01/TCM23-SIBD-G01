enum MetodoPagamento {

  mbway = "MBWay",
  cartaoDeCredito = "Cartão de Crédito",
  cartaoDedebito = "Cartão de Débito",
  dinheiro = "Dinheiro"
}
