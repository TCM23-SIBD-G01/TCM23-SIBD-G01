enum Sexo {
  homem = "Homem",
  mulher = "Mulher",
  unissexo = "Unissexo"
}
