enum MetodoEnvio {

  correiosNormal = "Correios Normal",
  transportadoraNormal = "Transportadora Normal",
  correiosExpress = "Correios Express",
  transportadoraExpress = "Transportadora Express"
}
