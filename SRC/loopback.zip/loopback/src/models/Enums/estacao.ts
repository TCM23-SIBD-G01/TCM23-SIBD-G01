enum Estacao {
  verao = "Verão",
  primavera = "Primavera",
  inverno = "Inverno",
  outono = "Outono"
}
