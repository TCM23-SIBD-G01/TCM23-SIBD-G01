enum Status {
  porFazer = "Por Fazer",
  emProgresso = "Em Progresso",
  acabado = "Acabado"
}
