enum Categoria {

  limpeza = "Limpeza",
  restock = "Restock",
  atendimentoAoCliente = "Atendimento ao Cliente"
}
