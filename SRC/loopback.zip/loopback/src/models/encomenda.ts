import {Entity, property} from '@loopback/repository';

export class Encomenda extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: false,
    required: true,
  })
  id: number;

  @property({
    type: 'string',
    required: true,
  })
  dataPedido: string;

  @property({
    type: 'string',
    required: true,
  })
  dataEntrega: string;

  @property({
    type: 'number',
    required: true,
  })
  idLoja: number;

  @property({
    type: 'number',
    required: true,
  })
  valorEncomenda: number;

  @property({
    type: 'enum',
    required: true,
  })
  metodoEnvio: MetodoEnvio;

  @property({
    type: 'string',
    required: true,
  })
  idFornecedor: string;

  @property({
    type: 'number',
    required: true,
  })
  quantidade: number;
}
